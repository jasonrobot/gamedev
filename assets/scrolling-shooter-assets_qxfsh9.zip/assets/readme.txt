Images from:
http://opengameart.org/content/aircrafts
http://www.praire-chicken.com/chabull/galleries

Sounds from:
http://opengameart.org/content/gunloop-8bit